/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agencia;

/**
 *
 * @author cleber.szczepanik
 */
// Pacote Nacional
class PacoteNacional extends PacoteViagem {
    public PacoteNacional(String destino, int duracao, double preco) {
        super(destino, duracao, preco);
    }

    @Override
    public String getTipo() {
        return "Nacional";
    }
}
