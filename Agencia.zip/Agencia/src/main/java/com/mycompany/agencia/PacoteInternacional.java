/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agencia;

/**
 *
 * @author cleber.szczepanik
 */
public class PacoteInternacional extends PacoteViagem {
    private String documentacaoNecessaria;

    public PacoteInternacional(String destino, int duracao, double preco, String documentacaoNecessaria) {
        super(destino, duracao, preco);
        this.documentacaoNecessaria = documentacaoNecessaria;
    }

    public String getDocumentacaoNecessaria() {
        return documentacaoNecessaria;
    }

    @Override
    public String getTipo() {
        return "Internacional";
    }
}