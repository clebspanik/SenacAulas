/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agencia;

/**
 *
 * @author cleber.szczepanik
 */
public class Cliente {
    private String nome;
    private List<PacoteViagem> pacotesAdquiridos;

    public Cliente(String nome) {
        this.nome = nome;
        this.pacotesAdquiridos = new ArrayList<>();
    }

    public void adquirirPacote(PacoteViagem pacote) {
        pacotesAdquiridos.add(pacote);
        System.out.println(nome + " adquiriu o pacote para " + pacote.getDestino() + " (" + pacote.getTipo() + ")");
    }

    public void listarPacotes() {
        System.out.println("Pacotes adquiridos por " + nome + ":");
        for (PacoteViagem pacote : pacotesAdquiridos) {
            System.out.println("- " + pacote.getDestino() + " (" + pacote.getTipo() + ") - R$ " + pacote.getPreco());
        }
    }
}
