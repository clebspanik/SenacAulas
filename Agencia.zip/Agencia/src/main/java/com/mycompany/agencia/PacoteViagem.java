/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.agencia;

/**
 *
 * @author cleber.szczepanik
 */

import java.util.ArrayList;
import java.util.List;

// Classe base para Pacotes
abstract class PacoteViagem {
    protected String destino;
    protected int duracao; // em dias
    protected double preco;
    protected List<String> atividades;

    public PacoteViagem(String destino, int duracao, double preco) {
        this.destino = destino;
        this.duracao = duracao;
        this.preco = preco;
        this.atividades = new ArrayList<>();
    }

    public void adicionarAtividade(String atividade) {
        atividades.add(atividade);
    }

    public String getDestino() {
        return destino;
    }

    public int getDuracao() {
        return duracao;
    }

    public double getPreco() {
        return preco;
    }

    public List<String> getAtividades() {
        return atividades;
    }

    public abstract String getTipo();
}